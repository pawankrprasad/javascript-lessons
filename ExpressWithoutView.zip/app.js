const express = require('express');

const app = express();


app.get('/', (req, res)=>{

    const student = {
        name:"Naren",
        class:"9th B",
        age:14,
        adderess:"Delhi"
    }

    res.send(student)
}); 

app.get('/student', (req, res)=>{

    console.log(req.query)

    console.log(req.headers)

    const student = {
        name:"Ravi",
        class:"9th B",
        age:14,
        adderess:"Delhi"
    }

    res.send(student)
}); 

app.get('/student/:id', (req, res)=>{

    console.log(req.params)
    const student = {
        name:"Ravi",
        class:"9th B",
        age:14,
        adderess:"Delhi"
    }

    res.send(student)
}); 

app.post('/student', (req, res)=>{


    console.log(req.body);
    const student = req.body;

    console.log(student)


    res.send(student)
}); 




app.listen(3000, ()=>{
    console.log("Application started at port number ", 3000);
})
